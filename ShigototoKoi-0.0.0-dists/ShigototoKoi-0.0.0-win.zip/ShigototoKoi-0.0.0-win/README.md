# Shigoto-to-Koi

0.0.0
Starting to add content

0.0.1
Added the draft for scenes 1 and 2 (business route)
Added placeholder character images
Added backgrounds
Fixed textboxes
